USE Kutuphane;
GO

-- Kitaplar ve Uyeler arasındaki many-to-many (çoka-çok) ilişkiyi yöneten tablo
CREATE TABLE OduncIslemleri (
    -- IslemID: Her ödünç alma işlemi için benzersiz işlem numarası.
    IslemID INT IDENTITY(1,1) PRIMARY KEY,
    
    -- ISBN: Kitaplar tablosuna referans veren Yabancı Anahtar (Foreign Key).
    ISBN NVARCHAR(20),
    
    -- UyeID: Uyeler tablosuna referans veren Yabancı Anahtar (Foreign Key).
    UyeID INT,
    
    -- VerilisTarihi: Kitabın teslim edildiği an.
    VerilisTarihi DATETIME DEFAULT GETDATE(),
    
    -- TeslimTarihi: Kitap geri getirildiğinde doldurulacak alan (Başlangıçta NULL).
    TeslimTarihi DATETIME,
    
    -- SonTeslimTarihi: Hesaplanmış sütun (Computed Column). 
    -- Veriliş tarihine otomatik olarak 15 gün ekleyerek iade limitini belirler.
    SonTeslimTarihi AS DATEADD(day, 15, VerilisTarihi), 

    -- İlişkisel kısıtlamalar: Silme veya güncelleme durumunda veri bütünlüğünü korur.
    CONSTRAINT FK_Kitap FOREIGN KEY (ISBN) REFERENCES Kitaplar(ISBN),
    CONSTRAINT FK_Uye FOREIGN KEY (UyeID) REFERENCES Uyeler(UyeID)
);
GO