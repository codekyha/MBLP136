-- İşlem yapılacak hedef veritabanını aktif hale getirir
USE Kutuphane; 
GO

-- Kitap bilgilerinin depolanacağı ana tabloyu oluşturur
CREATE TABLE Kitaplar (
    -- ISBN: Uluslararası Standart Kitap Numarası. 
    -- PRIMARY KEY: Bu sütunu 'Birincil Anahtar' yapar; her kitap için benzersizdir ve boş bırakılamaz.
    -- NVARCHAR(20): 20 karaktere kadar değişken uzunluklu Unicode (her dilden karakter destekleyen) metin saklar.
    ISBN NVARCHAR(20) PRIMARY KEY,
    
    -- Baslik: Kitabın adı. 
    -- NOT NULL: Bu alanın boş geçilmesini engeller; her kitabın mutlaka bir ismi olmalıdır.
    Baslik NVARCHAR(255) NOT NULL,
    
    -- Yazar: Yazar ismi. Boş bırakılabilir (NULL).
    Yazar NVARCHAR(255),
    
    -- SayfaSayisi: Tamsayı (Integer) veri tipi.
    -- CONSTRAINT CHK_SayfaSayisi: Veri tutarlılığını sağlamak için bir 'Kontrol Kısıtlaması' ekler.
    -- CHECK (SayfaSayisi > 0): Matematiksel mantık çerçevesinde sayfa sayısının negatif veya sıfır olmamasını garanti eder.
    -- Formül: $$ \forall x \in \text{SayfaSayisi}, x > 0 $$
    SayfaSayisi INT CONSTRAINT CHK_SayfaSayisi CHECK (SayfaSayisi > 0),
    
    -- YayinTarihi: Kitabın basıldığı tarih bilgisini saklar (Yıl-Ay-Gün).
    YayinTarihi DATE,
    
    -- Fiyat: Ondalıklı sayı tipi. 
    -- DECIMAL(10, 2): Toplamda 10 basamak uzunluğunda, bunun 2 basamağı virgülden sonra olacak şekilde (Örn: 99999999.99) para birimi saklar.
    Fiyat DECIMAL(10, 2),
    
    -- EklenmeTarihi: Kaydın veritabanına girdiği tarih ve saat bilgisi.
    -- DEFAULT GETDATE(): Eğer kullanıcı bir tarih girmezse, sistem o anki tarihi otomatik olarak atar.
    EklenmeTarihi DATETIME DEFAULT GETDATE()
);
GO

-- Mevcut tabloya ilk veri girişini (DML - Data Manipulation Language) gerçekleştirir
-- Sadece ISBN ve Baslik sütunlarına veri gönderilir; diğerleri NULL veya DEFAULT değerlerini alır.
INSERT INTO Kitaplar (ISBN, Baslik) 
VALUES ('978-605', 'Veri Tabani Sistemleri');
GO