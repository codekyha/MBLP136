-- Hedef veritabanını seçer. Tüm işlemler bu veritabanı altında yürütülür.
USE Kutuphane;
GO

-- Kütüphaneye kayıtlı üyelerin kişisel ve iletişim verilerini saklamak için tablo oluşturur.
CREATE TABLE Uyeler (
    -- UyeID: Sistem tarafından otomatik atanan benzersiz kimlik numarası.
    -- IDENTITY(1,1): İlk kayıt 1'den başlar ve her yeni üyede 1 artar (Seed=1, Increment=1).
    -- PRIMARY KEY: Bu alanı 'Birincil Anahtar' yaparak indeksler; hızlı erişim sağlar ve boş bırakılamaz.
    UyeID INT IDENTITY(1,1) PRIMARY KEY,
    
    -- TCKimlikNo: Türkiye Cumhuriyeti Kimlik Numarası.
    -- NCHAR(11): 11 karakterlik sabit uzunluklu alan. Değişken olmadığı için bellek yönetimi daha öngörülebilirdir.
    -- UNIQUE: Aynı TC numarasıyla birden fazla üye kaydı açılmasını veritabanı seviyesinde engeller.
    -- NOT NULL: Bu alanın doldurulması zorunludur.
    TCKimlikNo NCHAR(11) UNIQUE NOT NULL,
    
    -- Ad ve Soyad: Üyenin isim bilgileri.
    -- NVARCHAR(100): 100 karaktere kadar Unicode (Türkçe karakter destekli) metin saklar.
    Ad NVARCHAR(100) NOT NULL,
    Soyad NVARCHAR(100) NOT NULL,
    
    -- Eposta: Üye ile iletişim kurulacak elektronik posta adresi.
    -- UNIQUE: Bir e-posta adresi sadece tek bir üyeye tanımlanabilir.
    Eposta NVARCHAR(255) UNIQUE,
    
    -- Telefon: İletişim numarası. Alan kodu ve format farklılıkları için NVARCHAR tercih edilmiştir.
    Telefon NVARCHAR(20),
    
    -- KayitTarihi: Üyenin sisteme ilk giriş yaptığı tarih.
    -- DATETIME: Tarih ve saat bilgisini birlikte tutar.
    -- DEFAULT GETDATE(): INSERT komutu sırasında tarih belirtilmezse, sunucunun o anki saatini otomatik yazar.
    KayitTarihi DATETIME DEFAULT GETDATE(),
    
    -- UyelikDurumu: Üyenin aktiflik/pasiflik statüsü.
    -- BIT: Bellekte çok az yer kaplayan veri tipi. 1 (Aktif) veya 0 (Pasif) değerlerini alır.
    -- DEFAULT 1: Yeni eklenen her üye varsayılan olarak 'Aktif' kabul edilir.
    UyelikDurumu BIT DEFAULT 1
);
GO