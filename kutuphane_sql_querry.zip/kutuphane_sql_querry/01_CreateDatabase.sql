-- SQL Server Management Studio (SSMS) için veritabanı oluşturma betiği
-- Sistem tablolarını kontrol ederek 'Kutuphane' isimli bir veritabanı olup olmadığına bakar
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'Kutuphane')
BEGIN
    -- Eğer veritabanı yoksa, fiziksel dosyaları oluşturur ve veritabanını başlatır
    CREATE DATABASE Kutuphane;
END
GO

-- Komutların bu noktadan itibaren 'Kutuphane' veritabanı üzerinde çalışmasını sağlar
USE Kutuphane;
GO