-- 1. Veritabanı Ortamı
IF NOT EXISTS (SELECT * FROM sys.databases WHERE name = 'SporSalonuDB')
BEGIN
    CREATE DATABASE SporSalonuDB;
END
GO

USE SporSalonuDB;
GO

-- 2. Çalışanlar Tablosu: Eğitmenler ve personel
CREATE TABLE Calisanlar (
    CalisanID INT IDENTITY(1,1) PRIMARY KEY,
    Ad NVARCHAR(100) NOT NULL,
    Soyad NVARCHAR(100) NOT NULL,
    Gorev NVARCHAR(50), -- Örn: Fitness Eğitmeni, Resepsiyon
    Maas DECIMAL(10, 2) CHECK (Maas > 0),
    IseBaslamaTarihi DATE DEFAULT GETDATE()
);

-- 3. Üyelik Tipleri: Paket yönetimi (Normalizasyon için ayrı tablo)
CREATE TABLE UyelikTipleri (
    TipID INT IDENTITY(1,1) PRIMARY KEY,
    TipAd NVARCHAR(50) NOT NULL, -- Örn: Gold, Silver, Standart
    AylikUcret DECIMAL(10, 2) NOT NULL,
    SureAy INT DEFAULT 1 -- Paketin kaç ay sürdüğü
);

-- 4. Üyeler Tablosu
CREATE TABLE Uyeler (
    UyeID INT IDENTITY(1,1) PRIMARY KEY,
    Ad NVARCHAR(100) NOT NULL,
    Soyad NVARCHAR(100) NOT NULL,
    TCNo NCHAR(11) UNIQUE NOT NULL,
    DogumTarihi DATE,
    TipID INT, -- Foreign Key: Üyelik Tipi
    KayitTarihi DATE DEFAULT GETDATE(),
    Durum BIT DEFAULT 1, -- 1: Aktif, 0: Pasif (Üyeliği dondurmuş)
    CONSTRAINT FK_UyeTip FOREIGN KEY (TipID) REFERENCES UyelikTipleri(TipID)
);

-- 5. Giriş-Çıkış Kayıtları: Hareket Verisi
CREATE TABLE GirisCikisLog (
    LogID BIGINT IDENTITY(1,1) PRIMARY KEY, -- Çok fazla kayıt olacağı için BIGINT
    UyeID INT,
    GirisZamani DATETIME DEFAULT GETDATE(),
    CikisZamani DATETIME, -- Üye çıkarken güncellenecek
    
    -- Fiziksel Kısıtlama: Çıkış zamanı girişten önce olamaz
    CONSTRAINT CHK_Zaman CHECK (CikisZamani > GirisZamani),
    CONSTRAINT FK_LogUye FOREIGN KEY (UyeID) REFERENCES Uyeler(UyeID)
);